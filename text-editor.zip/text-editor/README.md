# Text editor

A Pen created on CodePen.

Original URL: [https://codepen.io/alecxsofrp/pen/XJmjoKo](https://codepen.io/alecxsofrp/pen/XJmjoKo).

