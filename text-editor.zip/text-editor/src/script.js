        let selectedFont = 'regular';
        let savedColors = [];
        let currentText = '';

        // Font mapping objects
        const fontMaps = {
            regular: 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
            bold: {
                'a': '𝐚', 'b': '𝐛', 'c': '𝐜', 'd': '𝐝', 'e': '𝐞', 'f': '𝐟', 'g': '𝐠', 'h': '𝐡', 'i': '𝐢', 'j': '𝐣', 'k': '𝐤', 'l': '𝐥', 'm': '𝐦', 'n': '𝐧', 'o': '𝐨', 'p': '𝐩', 'q': '𝐪', 'r': '𝐫', 's': '𝐬', 't': '𝐭', 'u': '𝐮', 'v': '𝐯', 'w': '𝐰', 'x': '𝐱', 'y': '𝐲', 'z': '𝐳',
                'A': '𝐀', 'B': '𝐁', 'C': '𝐂', 'D': '𝐃', 'E': '𝐄', 'F': '𝐅', 'G': '𝐆', 'H': '𝐇', 'I': '𝐈', 'J': '𝐉', 'K': '𝐊', 'L': '𝐋', 'M': '𝐌', 'N': '𝐍', 'O': '𝐎', 'P': '𝐏', 'Q': '𝐐', 'R': '𝐑', 'S': '𝐒', 'T': '𝐓', 'U': '𝐔', 'V': '𝐕', 'W': '𝐖', 'X': '𝐗', 'Y': '𝐘', 'Z': '𝐙'
            },
            italic: 'abcdefghijklmnopqrstuvwxyz𝑎𝑏𝑐𝑑𝑒𝑓𝑔ℎ𝑖𝑗𝑘𝑙𝑚𝑛𝑜𝑝𝑞𝑟𝑠𝑡𝑢𝑣𝑤𝑥𝑦𝑧ABCDEFGHIJKLMNOPQRSTUVWXYZ𝐴𝐵𝐶𝐷𝐸𝐹𝐺𝐻𝐼𝐽𝐾𝐿𝑀𝑁𝑂𝑃𝑄𝑅𝑆𝑇𝑈𝑉𝑊𝑋𝑌𝑍',
            script: 'abcdefghijklmnopqrstuvwxyz𝒶𝒷𝒸𝒹ℯ𝒻ℊ𝒽𝒾𝒿𝓀𝓁𝓂𝓃ℴ𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏ABCDEFGHIJKLMNOPQRSTUVWXYZ𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩ℴ𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵',
            boldscript: 'abcdefghijklmnopqrstuvwxyz𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃ABCDEFGHIJKLMNOPQRSTUVWXYZ𝓐𝓑𝓒𝓓𝓔𝓕𝓖𝓗𝓘𝓙𝓚𝓛𝓜𝓝𝓞𝓟𝓠𝓡𝓢𝓣𝓤𝓥𝓦𝓧𝓨𝓩',
            doublestruck: 'abcdefghijklmnopqrstuvwxyz𝕒𝕓𝕔𝕕𝖊𝖋𝖌𝖍𝖎𝖏𝖐𝖑𝖒𝖓𝖔𝖕𝖖𝖗𝖘𝖙𝖚𝖛𝖜𝖝𝖞𝖟ABCDEFGHIJKLMNOPQRSTUVWXYZ𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ',
            fraktur: 'abcdefghijklmnopqrstuvwxyz𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷ABCDEFGHIJKLMNOPQRSTUVWXYZ𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ',
            monospace: 'abcdefghijklmnopqrstuvwxyz𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣ABCDEFGHIJKLMNOPQRSTUVWXYZ𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉',
            sans: 'abcdefghijklmnopqrstuvwxyz𝖺𝖻𝖼𝖽𝖾𝖿𝗀𝗁𝗂𝗃𝗄𝗅𝗆𝗇𝗈𝗉𝗊𝗋𝗌𝗍𝗎𝗏𝗐𝗑𝗒𝗓ABCDEFGHIJKLMNOPQRSTUVWXYZ𝖠𝖡𝖢𝖣𝖤𝖥𝖦𝖧𝖨𝖩𝖪𝖫𝖬𝖭𝖮𝖯𝖰𝖱𝖲𝖳𝖴𝖵𝖶𝖷𝖸𝖹',
            boldsans: 'abcdefghijklmnopqrstuvwxyz𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇ABCDEFGHIJKLMNOPQRSTUVWXYZ𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭',
            wide: 'abcdefghijklmnopqrstuvwxyzａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚABCDEFGHIJKLMNOPQRSTUVWXYZＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ',
            smallcaps: 'abcdefghijklmnopqrstuvwxyzᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢABCDEFGHIJKLMNOPQRSTUVWXYZᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ'
        };

        // Load saved colors from memory on page load
        function loadSavedColors() {
            const defaultColors = ['#667eea', '#764ba2', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7', '#dda0dd'];
            savedColors = defaultColors;
            updateColorPalette();
        }

        function saveColor() {
            const colorInput = document.getElementById('textColor');
            const newColor = colorInput.value;
            
            if (!savedColors.includes(newColor)) {
                savedColors.push(newColor);
                updateColorPalette();
            }
        }

        function updateColorPalette() {
            const palette = document.getElementById('colorPalette');
            
            if (savedColors.length === 0) {
                palette.innerHTML = '<div class="no-colors-message">No saved colors yet. Use the color picker and click "Save Color" to add some!</div>';
                return;
            }
            
            palette.innerHTML = savedColors.map((color, index) => `
                <div class="saved-color" style="background-color: ${color}" 
                     onclick="selectSavedColor('${color}')" 
                     title="Click to use this color">
                    <button class="delete-color" onclick="deleteSavedColor(${index})" title="Delete color">×</button>
                </div>
            `).join('');
        }

        function selectSavedColor(color) {
            document.getElementById('textColor').value = color;
            document.getElementById('useColor').checked = true;
            
            // Update visual selection
            document.querySelectorAll('.saved-color').forEach(el => el.classList.remove('selected'));
            event.currentTarget.classList.add('selected');
        }

        function deleteSavedColor(index) {
            event.stopPropagation();
            savedColors.splice(index, 1);
            updateColorPalette();
        }

        // Initialize font selection
        document.querySelectorAll('.font-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.font-option').forEach(opt => opt.classList.remove('selected'));
                this.classList.add('selected');
                selectedFont = this.dataset.font;
            });
        });

        function convertToFont(text, font) {
            if (font === 'regular') return text;
            
            if (font === 'bold') {
                return text.split('').map(char => {
                    return fontMaps.bold[char] || char;
                }).join('');
            }
            
            if (fontMaps[font] && typeof fontMaps[font] === 'string') {
                const normal = fontMaps.regular;
                const special = fontMaps[font];
                const normalChars = normal.substring(0, 26) + normal.substring(26, 52);
                const specialChars = special.substring(26, 52) + special.substring(78, 104);
                
                return text.split('').map(char => {
                    const index = normalChars.indexOf(char);
                    if (index !== -1) {
                        return specialChars[index];
                    }
                    return char;
                }).join('');
            }
            
            return text;
        }

        function applyFontToSelection() {
            const textarea = document.getElementById('inputText');
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const selectedText = textarea.value.substring(start, end);
            
            if (selectedText.length === 0) {
                alert('Please select some text first!');
                return;
            }
            
            const convertedText = convertToFont(selectedText, selectedFont);
            const beforeText = textarea.value.substring(0, start);
            const afterText = textarea.value.substring(end);
            
            // Update the textarea with the new text
            textarea.value = beforeText + convertedText + afterText;
            
            // Update the preview
            updatePreview();
            
            // Set cursor position after the converted text
            const newPosition = start + convertedText.length;
            textarea.setSelectionRange(newPosition, newPosition);
            textarea.focus();
        }

        function resetText() {
            document.getElementById('inputText').value = '';
            updatePreview();
        }

        function applySpacing(type) {
            const textarea = document.getElementById('inputText');
            let text = textarea.value;
            
            switch(type) {
                case 'double':
                    text = text.split('').join(' ');
                    break;
                case 'triple':
                    text = text.split('').join('  ');
                    break;
                case 'normal':
                default:
                    // Remove extra spaces between characters (keep only single spaces between words)
                    text = text.replace(/(.)\s+(.)/g, (match, char1, char2) => {
                        // If both characters are letters/numbers, keep single space
                        if (/\w/.test(char1) && /\w/.test(char2)) {
                            return char1 + ' ' + char2;
                        }
                        // Otherwise keep original
                        return match;
                    });
                    break;
            }
            
            textarea.value = text;
            updatePreview();
        }

        function updatePreview() {
            const text = document.getElementById('inputText').value;
            const previewArea = document.getElementById('previewArea');
            
            if (text.trim() === '') {
                previewArea.textContent = 'Your formatted text will appear here as you work...';
                previewArea.style.color = '#999';
                return;
            }
            
            previewArea.textContent = text;
            previewArea.style.color = '#333';
        }

        function generateFinalOutput() {
            const inputText = document.getElementById('inputText').value;
            
            if (!inputText.trim()) {
                alert('Please enter some text first!');
                return;
            }
            
            // Set plain text output
            document.getElementById('outputText').value = inputText;
            
            // Generate HTML output with color if enabled
            const useColor = document.getElementById('useColor').checked;
            const color = document.getElementById('textColor').value;
            
            let htmlOutput = inputText;
            if (useColor) {
                htmlOutput = `<span style="color: ${color}">${inputText}</span>`;
            }
            
            document.getElementById('htmlOutput').value = htmlOutput;
        }

        function copyToClipboard() {
            const outputText = document.getElementById('outputText');
            outputText.select();
            document.execCommand('copy');
            
            const btn = event.target;
            const originalText = btn.textContent;
            btn.textContent = 'Copied!';
            btn.style.background = '#218838';
            
            setTimeout(() => {
                btn.textContent = originalText;
                btn.style.background = '#28a745';
            }, 2000);
        }

        function copyHtmlToClipboard() {
            const htmlOutput = document.getElementById('htmlOutput');
            htmlOutput.select();
            document.execCommand('copy');
            
            const btn = event.target;
            const originalText = btn.textContent;
            btn.textContent = 'Copied!';
            btn.style.background = '#218838';
            
            setTimeout(() => {
                btn.textContent = originalText;
                btn.style.background = '#28a745';
            }, 2000);
        }

        function clearAll() {
            document.getElementById('inputText').value = '';
            document.getElementById('outputText').value = '';
            document.getElementById('htmlOutput').value = '';
            
            // Reset to defaults
            document.querySelectorAll('.font-option').forEach(opt => opt.classList.remove('selected'));
            document.querySelector('[data-font="regular"]').classList.add('selected');
            selectedFont = 'regular';
            
            document.getElementById('useColor').checked = false;
            updatePreview();
        }

        // Update preview when typing
        document.getElementById('inputText').addEventListener('input', updatePreview);

        // Initialize the app
        window.addEventListener('DOMContentLoaded', function() {
            loadSavedColors();
            updatePreview();
        });